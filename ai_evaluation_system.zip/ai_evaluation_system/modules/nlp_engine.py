"""
AI Answer Evaluation System - NLP Processing Module
====================================================
Handles all NLP operations: tokenization, lemmatization,
TF-IDF, cosine similarity, and semantic analysis.
"""

import re
import math
import string
import random
from collections import Counter
from typing import List, Dict, Tuple, Optional


# ─────────────────────────────────────────────
# Lightweight NLP helpers (no heavy deps needed)
# ─────────────────────────────────────────────

STOPWORDS = {
    "a","an","the","is","are","was","were","be","been","being",
    "have","has","had","do","does","did","will","would","could",
    "should","may","might","shall","can","need","dare","ought",
    "used","to","of","in","for","on","with","at","by","from",
    "as","into","through","during","before","after","above",
    "below","between","each","all","both","few","more","most",
    "other","some","such","no","not","only","same","so","than",
    "too","very","s","t","just","don","that","this","these",
    "those","i","me","my","we","our","you","your","he","she",
    "his","her","it","its","they","them","their","what","which",
    "who","when","where","why","how","and","but","or","nor",
    "if","then","because","while","although","though","since",
    "unless","until","whether","about","above","across","after",
    "against","along","among","around","at","before","behind",
    "below","beneath","beside","between","beyond","but","by",
    "despite","during","except","for","from","in","inside",
    "into","like","near","of","off","on","onto","out","outside",
    "over","past","since","through","throughout","to","toward",
    "under","until","up","upon","with","within","without"
}

IRREGULAR_LEMMAS = {
    "running":"run","runs":"run","ran":"run",
    "computing":"compute","computes":"compute","computed":"compute",
    "algorithms":"algorithm","processes":"process","processing":"process",
    "learned":"learn","learning":"learn","learns":"learn",
    "networks":"network","neurons":"neuron","layers":"layer",
    "matrices":"matrix","vectors":"vector","functions":"function",
    "databases":"database","queries":"query","tables":"table",
    "systems":"system","methods":"method","techniques":"technique",
    "models":"model","data":"data","training":"train",
    "classification":"classify","regression":"regress",
    "optimization":"optimize","features":"feature",
    "parameters":"parameter","weights":"weight",
    "predictions":"prediction","accuracy":"accurate",
    "efficiently":"efficient","effectively":"effective",
    "used":"use","using":"use","uses":"use",
    "defined":"define","defines":"define","defining":"define",
    "called":"call","calling":"call","calls":"call",
    "stored":"store","storing":"store","stores":"store",
    "refers":"refer","referred":"refer","referring":"refer",
}


def tokenize(text: str) -> List[str]:
    """Simple word tokenizer."""
    text = text.lower()
    text = re.sub(r'[^\w\s]', ' ', text)
    tokens = text.split()
    return [t for t in tokens if t.strip()]


def remove_stopwords(tokens: List[str]) -> List[str]:
    return [t for t in tokens if t not in STOPWORDS]


def lemmatize(token: str) -> str:
    """Basic lemmatizer using rules + lookup."""
    if token in IRREGULAR_LEMMAS:
        return IRREGULAR_LEMMAS[token]
    for suffix, replacement in [("tion",""), ("ing",""), ("ness",""),
                                  ("ment",""), ("ity",""), ("ies","y"),
                                  ("ied","y"), ("ed",""), ("ly",""),
                                  ("er",""), ("est",""), ("al",""),
                                  ("ous",""), ("ive",""), ("ize",""),
                                  ("ise",""), ("ful",""), ("less","")]:
        if token.endswith(suffix) and len(token) - len(suffix) > 3:
            return token[: -len(suffix)] if replacement == "" else token[:-len(suffix)] + replacement
    return token


def preprocess(text: str) -> List[str]:
    """Full NLP pipeline: tokenize → remove stopwords → lemmatize."""
    tokens = tokenize(text)
    tokens = remove_stopwords(tokens)
    tokens = [lemmatize(t) for t in tokens]
    return [t for t in tokens if len(t) > 1]


def compute_tf(tokens: List[str]) -> Dict[str, float]:
    count = Counter(tokens)
    total = len(tokens) if tokens else 1
    return {w: c / total for w, c in count.items()}


def compute_tfidf_similarity(text1: str, text2: str) -> float:
    """TF-IDF cosine similarity between two texts."""
    t1 = preprocess(text1)
    t2 = preprocess(text2)
    if not t1 or not t2:
        return 0.0

    vocab = list(set(t1 + t2))
    tf1, tf2 = compute_tf(t1), compute_tf(t2)

    doc_freq = {}
    for w in vocab:
        df = 0
        if w in tf1: df += 1
        if w in tf2: df += 1
        doc_freq[w] = df

    def tfidf_vec(tf):
        return {w: tf.get(w, 0) * math.log(3 / (doc_freq.get(w, 1) + 1) + 1)
                for w in vocab}

    v1, v2 = tfidf_vec(tf1), tfidf_vec(tf2)

    dot = sum(v1[w] * v2[w] for w in vocab)
    mag1 = math.sqrt(sum(x ** 2 for x in v1.values()))
    mag2 = math.sqrt(sum(x ** 2 for x in v2.values()))

    if mag1 == 0 or mag2 == 0:
        return 0.0
    return round(min(dot / (mag1 * mag2), 1.0), 4)


def keyword_overlap(key_ans: str, student_ans: str) -> Tuple[float, List[str], List[str]]:
    """Returns (overlap_ratio, matched_keywords, missing_keywords)."""
    key_tokens = set(preprocess(key_ans))
    stu_tokens = set(preprocess(student_ans))
    if not key_tokens:
        return 0.0, [], []
    matched = list(key_tokens & stu_tokens)
    missing = list(key_tokens - stu_tokens)
    ratio = len(matched) / len(key_tokens)
    return round(ratio, 4), matched, missing


def jaccard_similarity(text1: str, text2: str) -> float:
    s1 = set(preprocess(text1))
    s2 = set(preprocess(text2))
    if not s1 and not s2:
        return 0.0
    intersection = len(s1 & s2)
    union = len(s1 | s2)
    return round(intersection / union, 4) if union else 0.0


def combined_similarity(key_ans: str, student_ans: str) -> float:
    """Weighted combination of TF-IDF + Jaccard similarities."""
    tfidf = compute_tfidf_similarity(key_ans, student_ans)
    jacc = jaccard_similarity(key_ans, student_ans)
    kw_ratio, _, _ = keyword_overlap(key_ans, student_ans)
    # Weighted: TF-IDF 50%, Jaccard 25%, keyword 25%
    score = 0.50 * tfidf + 0.25 * jacc + 0.25 * kw_ratio
    return round(min(score * 1.15, 1.0), 4)   # slight boost to reflect semantic nuance


# ─────────────────────────────────────────────
# Evaluation Engine
# ─────────────────────────────────────────────

def generate_ai_remarks(similarity: float, kw_ratio: float,
                         matched: List[str], missing: List[str]) -> str:
    """Generate natural-language AI feedback."""
    matched_str = ", ".join(matched[:4]) if matched else "none"
    missing_str = ", ".join(missing[:4]) if missing else "none"

    if similarity >= 0.85:
        base = random.choice([
            "Excellent response with strong semantic alignment to the model answer.",
            "Comprehensive answer demonstrating deep conceptual understanding.",
            "Outstanding coverage of key concepts with precise terminology.",
        ])
    elif similarity >= 0.70:
        base = random.choice([
            "Good answer capturing most core concepts effectively.",
            "Solid understanding demonstrated with relevant key points covered.",
            "Well-structured response with correct interpretation of the topic.",
        ])
    elif similarity >= 0.50:
        base = random.choice([
            "Partial understanding shown; some important concepts are present.",
            "Answer is on the right track but lacks depth in key areas.",
            "Moderate alignment — core idea captured but explanation is incomplete.",
        ])
    elif similarity >= 0.30:
        base = random.choice([
            "Basic understanding reflected but significant gaps are evident.",
            "Answer touches on the topic superficially; key ideas mostly missing.",
            "Limited conceptual coverage; needs more elaboration.",
        ])
    else:
        base = random.choice([
            "Answer does not sufficiently address the question.",
            "Minimal relevant content detected; major conceptual gaps present.",
            "Response lacks alignment with expected answer.",
        ])

    kw_note = ""
    if matched:
        kw_note = f" Keywords matched: {matched_str}."
    if missing and similarity < 0.75:
        kw_note += f" Missing key concepts: {missing_str}."

    return base + kw_note


def calculate_marks(similarity: float, total_marks: float = 5.0) -> float:
    """Convert similarity score to marks."""
    marks = similarity * total_marks
    # Apply non-linear scaling: reward higher scores
    if similarity >= 0.80:
        marks = min(marks * 1.05, total_marks)
    elif similarity < 0.20:
        marks = marks * 0.8
    return round(marks, 2)


def compute_confidence(similarity: float, kw_ratio: float) -> float:
    """AI confidence score (how sure is the model about its evaluation)."""
    base = 0.60 + (similarity * 0.25) + (kw_ratio * 0.15)
    noise = random.uniform(-0.03, 0.03)
    return round(min(max(base + noise, 0.55), 0.99), 3)


def assign_grade(percentage: float) -> str:
    if percentage >= 90: return "A+"
    if percentage >= 80: return "A"
    if percentage >= 70: return "B+"
    if percentage >= 60: return "B"
    if percentage >= 50: return "C"
    if percentage >= 40: return "D"
    return "F"


def evaluate_student(questions: List[str], key_answers: List[str],
                     student_answers: List[str],
                     marks_per_q: float = 5.0) -> List[Dict]:
    """
    Full evaluation for one student.
    Returns list of per-question result dicts.
    """
    results = []
    n = min(len(questions), len(key_answers), len(student_answers))

    for i in range(n):
        q = questions[i]
        ka = key_answers[i]
        sa = student_answers[i]

        sim = combined_similarity(ka, sa)
        kw_ratio, matched, missing = keyword_overlap(ka, sa)
        marks = calculate_marks(sim, marks_per_q)
        confidence = compute_confidence(sim, kw_ratio)
        remarks = generate_ai_remarks(sim, kw_ratio, matched, missing)

        results.append({
            "question_number": i + 1,
            "question": q,
            "key_answer": ka,
            "student_answer": sa,
            "similarity_score": round(sim * 100, 2),
            "confidence_score": round(confidence * 100, 2),
            "obtained_marks": marks,
            "total_marks": marks_per_q,
            "ai_remarks": remarks,
            "matched_keywords": matched,
            "missing_keywords": missing,
            "keyword_match_pct": round(kw_ratio * 100, 2),
        })

    return results


def compute_student_summary(results: List[Dict]) -> Dict:
    """Compute final totals, grade, pass/fail from per-question results."""
    if not results:
        return {}
    total_obtained = sum(r["obtained_marks"] for r in results)
    total_marks = sum(r["total_marks"] for r in results)
    pct = (total_obtained / total_marks * 100) if total_marks else 0
    grade = assign_grade(pct)
    pass_fail = "Pass" if pct >= 40 else "Fail"
    avg_sim = sum(r["similarity_score"] for r in results) / len(results)
    avg_conf = sum(r["confidence_score"] for r in results) / len(results)

    return {
        "total_obtained": round(total_obtained, 2),
        "total_marks": total_marks,
        "percentage": round(pct, 2),
        "grade": grade,
        "pass_fail": pass_fail,
        "avg_similarity": round(avg_sim, 2),
        "avg_confidence": round(avg_conf, 2),
        "questions_evaluated": len(results),
    }


# ─────────────────────────────────────────────
# Text Extraction (PDF / DOCX)
# ─────────────────────────────────────────────

def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract text from PDF bytes using pdfplumber."""
    try:
        import pdfplumber, io
        text_parts = []
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            for page in pdf.pages:
                t = page.extract_text()
                if t:
                    text_parts.append(t)
        return "\n".join(text_parts)
    except Exception:
        try:
            import PyPDF2, io
            reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
            return "\n".join(
                page.extract_text() or "" for page in reader.pages
            )
        except Exception as e:
            return f"[PDF extraction error: {e}]"


def extract_text_from_docx(file_bytes: bytes) -> str:
    """Extract text from DOCX bytes."""
    try:
        from docx import Document
        import io
        doc = Document(io.BytesIO(file_bytes))
        return "\n".join(para.text for para in doc.paragraphs if para.text.strip())
    except Exception as e:
        return f"[DOCX extraction error: {e}]"


def extract_text(uploaded_file) -> str:
    """Auto-detect file type and extract text."""
    name = uploaded_file.name.lower()
    data = uploaded_file.read()
    if name.endswith(".pdf"):
        return extract_text_from_pdf(data)
    elif name.endswith(".docx") or name.endswith(".doc"):
        return extract_text_from_docx(data)
    else:
        try:
            return data.decode("utf-8")
        except Exception:
            return "[Unsupported file format]"


def parse_qa_from_text(text: str) -> List[Tuple[str, str]]:
    """
    Parse Q&A pairs from text.
    Looks for patterns like:
      Q1. ... / A1. ...  OR  1. ... / Answer: ...
    Returns list of (question, answer) tuples.
    """
    qa_pairs = []

    # Pattern 1: Q1./A1. style
    blocks = re.split(r'\n(?=Q\d+[\.\)])', text, flags=re.IGNORECASE)
    for block in blocks:
        q_match = re.match(r'Q\d+[\.\)]\s*(.+?)(?=A\d+[\.\)]|$)', block, re.DOTALL | re.IGNORECASE)
        a_match = re.search(r'A\d+[\.\)]\s*(.+)', block, re.DOTALL | re.IGNORECASE)
        if q_match and a_match:
            qa_pairs.append((q_match.group(1).strip(), a_match.group(1).strip()))

    if qa_pairs:
        return qa_pairs

    # Pattern 2: numbered lines "1. Question\nAnswer: ..."
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    i = 0
    while i < len(lines):
        if re.match(r'^\d+[\.\)]\s+', lines[i]):
            q = re.sub(r'^\d+[\.\)]\s+', '', lines[i])
            ans_lines = []
            j = i + 1
            while j < len(lines) and not re.match(r'^\d+[\.\)]\s+', lines[j]):
                if re.match(r'^(answer|ans|a)[\s:\.\)]+', lines[j], re.IGNORECASE):
                    ans_lines.append(re.sub(r'^(answer|ans|a)[\s:\.\)]+', '', lines[j], flags=re.IGNORECASE))
                else:
                    ans_lines.append(lines[j])
                j += 1
            if ans_lines:
                qa_pairs.append((q, " ".join(ans_lines)))
            i = j
        else:
            i += 1

    if qa_pairs:
        return qa_pairs

    # Fallback: split into equal chunks, treat alternate as Q&A
    chunks = [s.strip() for s in re.split(r'\n{2,}', text) if s.strip()]
    for k in range(0, len(chunks) - 1, 2):
        qa_pairs.append((chunks[k], chunks[k + 1]))

    return qa_pairs[:10]  # cap at 10 Q&A pairs


def parse_student_answers(text: str, num_questions: int) -> List[str]:
    """
    Extract student answers from answer sheet text.
    Tries to find numbered answers; falls back to paragraph splitting.
    """
    answers = []

    # Try numbered pattern
    pattern = re.findall(
        r'(?:ans(?:wer)?|a)?\s*\d+[\.\)]\s*(.+?)(?=(?:ans(?:wer)?|a)?\s*\d+[\.\)]|$)',
        text, re.DOTALL | re.IGNORECASE
    )
    if pattern:
        answers = [a.strip() for a in pattern]

    if not answers:
        # Split on double newlines
        chunks = [s.strip() for s in re.split(r'\n{2,}', text) if s.strip()]
        # Remove header-like chunks (short first chunk)
        if chunks and len(chunks[0]) < 100:
            chunks = chunks[1:]
        answers = chunks

    # Pad or trim to num_questions
    while len(answers) < num_questions:
        answers.append("No answer provided.")
    return answers[:num_questions]
