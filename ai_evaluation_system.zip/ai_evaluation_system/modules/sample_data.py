"""
Sample Data Generator
=====================
Creates realistic sample Q&A data for demonstration.
"""

SAMPLE_QUESTION_PAPER = """EXAMINATION PAPER
Subject: Computer Science & Artificial Intelligence
Maximum Marks: 50 | Time: 3 Hours

Q1. What is machine learning and how does it differ from traditional programming?

Q2. Explain the concept of neural networks with reference to biological neurons.

Q3. Describe the process of gradient descent in optimization of machine learning models.

Q4. What is Natural Language Processing (NLP)? List any four important NLP techniques.

Q5. Define overfitting and underfitting in machine learning. How can they be prevented?

Q6. Explain the significance of the TF-IDF algorithm in text analysis.

Q7. What is the difference between supervised and unsupervised learning? Give examples.

Q8. Describe the architecture and applications of a Convolutional Neural Network (CNN).

Q9. What is transfer learning? How does it benefit model training on limited datasets?

Q10. Explain the concept of cosine similarity and its application in NLP tasks.
"""

SAMPLE_KEY_ANSWERS = """KEY ANSWER SHEET
Subject: Computer Science & Artificial Intelligence

A1. Machine learning is a subset of artificial intelligence where systems learn from data to improve performance without being explicitly programmed. Unlike traditional programming where rules are hardcoded by developers, machine learning algorithms automatically discover patterns and rules from training data. The system improves its predictions or decisions through experience and exposure to more data.

A2. Neural networks are computational models inspired by the human brain's biological neural structure. Just as biological neurons receive signals through dendrites, process them in the cell body, and transmit outputs through axons, artificial neurons receive numerical inputs, apply weights and activation functions, and pass outputs to subsequent layers. Networks consist of input, hidden, and output layers interconnected by weighted edges that are trained through backpropagation.

A3. Gradient descent is an iterative optimization algorithm that minimizes a loss function by updating model parameters in the direction of the negative gradient. Starting from initial random weights, the algorithm computes the gradient of the loss with respect to each parameter, then subtracts a fraction (learning rate) of that gradient from the parameter. This process repeats until convergence to a local or global minimum. Variants include stochastic gradient descent (SGD) and mini-batch gradient descent for efficiency.

A4. Natural Language Processing (NLP) is a branch of AI that enables computers to understand, interpret, and generate human language. Important NLP techniques include: (1) Tokenization — splitting text into words or subwords; (2) Stopword removal — filtering common words that add little semantic value; (3) Lemmatization — reducing words to their base form; (4) TF-IDF — measuring word importance across documents; (5) Named Entity Recognition — identifying entities like names and places; (6) Sentiment Analysis — determining emotional tone of text.

A5. Overfitting occurs when a model learns the training data too well including noise and random fluctuations, resulting in poor generalization to new data. Underfitting occurs when a model is too simple to capture the underlying patterns in data. Prevention strategies include: cross-validation, regularization techniques (L1/L2), dropout layers in neural networks, early stopping, increasing training data volume, and reducing model complexity for underfitting.

A6. TF-IDF (Term Frequency-Inverse Document Frequency) is a statistical measure used to evaluate how important a word is to a document in a corpus. TF measures how frequently a term appears in a document, while IDF penalizes terms appearing across many documents (common words). The product TF×IDF assigns high scores to terms that are frequent in a specific document but rare across the corpus, helping identify distinctive and informative terms for text classification and information retrieval.

A7. Supervised learning uses labeled training data where the correct output is provided, enabling the model to learn input-output mappings. Examples include linear regression, decision trees, and support vector machines used for classification and regression tasks. Unsupervised learning discovers hidden patterns in unlabeled data without predefined outputs. Examples include K-means clustering for grouping data, PCA for dimensionality reduction, and autoencoders for representation learning.

A8. Convolutional Neural Networks (CNNs) are deep learning architectures designed primarily for processing grid-structured data like images. Their architecture consists of convolutional layers that apply filters to detect local features (edges, textures, shapes), pooling layers that reduce spatial dimensions while retaining important features, and fully connected layers for final classification. CNNs are applied in image recognition, object detection, medical image analysis, facial recognition, and autonomous vehicle vision systems.

A9. Transfer learning is a machine learning technique where a model trained on one task or large dataset is repurposed as the starting point for a different but related task. It benefits limited-dataset scenarios by leveraging pre-learned feature representations, reducing training time, requiring less labeled data, and often achieving higher accuracy. Popular pre-trained models like VGG, ResNet, BERT, and GPT are fine-tuned on domain-specific datasets for specialized tasks.

A10. Cosine similarity measures the cosine of the angle between two non-zero vectors in a multidimensional space, producing a value between -1 and 1. In NLP, documents or sentences are represented as TF-IDF or embedding vectors, and cosine similarity measures their semantic relatedness regardless of vector magnitude. A cosine similarity of 1 indicates identical direction (highly similar), 0 indicates orthogonality (unrelated), and -1 indicates opposite directions. It is widely used in document retrieval, recommendation systems, and answer evaluation.
"""

SAMPLE_STUDENT_ANSWERS = {
    "STU001": {
        "name": "Arjun Sharma",
        "subject": "Computer Science",
        "answers": """STUDENT ANSWER SHEET
Student ID: STU001 | Name: Arjun Sharma | Subject: Computer Science

Answer 1. Machine learning is a field of AI that enables computers to learn from data automatically. In traditional programming, programmers write specific rules, but in machine learning the system discovers patterns from examples and improves with more data. It uses statistical techniques to build models that make predictions.

Answer 2. Neural networks are inspired by brain neurons. They have input layers, hidden layers, and output layers. Each node receives inputs and applies activation functions. The connection weights are trained using backpropagation. They mimic biological neurons receiving signals and passing them forward.

Answer 3. Gradient descent is an algorithm to minimize loss functions. It computes gradients and updates weights iteratively by moving in the opposite direction of the gradient. The learning rate controls step size. It keeps updating until the minimum is reached. There are batch, stochastic, and mini-batch variants.

Answer 4. NLP is Natural Language Processing which helps computers understand human language. Techniques include tokenization, lemmatization, stopword removal, and TF-IDF. These help process and analyze text data for various applications like chatbots and search engines.

Answer 5. Overfitting is when a model memorizes training data but fails on new data. Underfitting is when model is too simple. We can prevent overfitting using regularization, dropout, and cross-validation. Getting more training data also helps prevent both problems.

Answer 6. TF-IDF stands for Term Frequency-Inverse Document Frequency. It measures word importance in documents. Words appearing frequently in one document but rarely in others get high TF-IDF scores. It is useful for text classification and search engines.

Answer 7. Supervised learning trains on labeled data with input-output pairs. Examples are classification and regression. Unsupervised learning finds patterns in unlabeled data. Examples are clustering and dimensionality reduction. The main difference is the presence or absence of labeled training data.

Answer 8. CNN is a deep learning model for images. It has convolutional layers to detect features like edges, pooling layers to reduce size, and fully connected layers for classification. CNNs are used in image recognition, object detection, and medical imaging applications.

Answer 9. Transfer learning reuses a pre-trained model on a new task. This saves training time and requires less data. Models like VGG and BERT are pre-trained on large datasets and fine-tuned on specific problems. It is very useful when we have limited labeled training data.

Answer 10. Cosine similarity measures the angle between two vectors. In NLP documents are represented as vectors and cosine similarity measures how similar they are. Value of 1 means identical and 0 means unrelated. It is used in document retrieval and recommendation systems.
"""
    },
    "STU002": {
        "name": "Priya Patel",
        "subject": "Data Structures",
        "answers": """STUDENT ANSWER SHEET
Student ID: STU002 | Name: Priya Patel | Subject: Data Structures

Answer 1. Machine learning allows systems to learn patterns from data without explicit rules. It is different from traditional programming because instead of writing if-else conditions, the algorithm learns from examples. More data generally leads to better performance.

Answer 2. Neural networks work like the human brain. They process information through connected neurons organized in layers. Each neuron computes a weighted sum of inputs and applies an activation function. Training adjusts the weights using backpropagation to minimize errors.

Answer 3. Gradient descent minimizes cost function by computing derivatives. We subtract the gradient multiplied by learning rate from weights each iteration. This continues until we reach convergence or minimum loss.

Answer 4. NLP helps machines understand text and speech. Tokenization breaks text into tokens. Stemming and lemmatization reduce words to root forms. Sentiment analysis determines positive or negative opinions in text.

Answer 5. Overfitting means model works well on training but poorly on test data. Solutions include dropout, regularization, and more data. Simple models can underfit the data by not learning enough patterns.

Answer 6. TF-IDF helps find important words. Common words like 'the' get low scores. Unique domain words get high scores. Used in search and text mining applications to rank document relevance.

Answer 7. In supervised learning we have labels. Classification predicts categories. Regression predicts numbers. Unsupervised finds hidden groups. K-means is a clustering algorithm that groups similar data without labels.

Answer 8. Convolutional layers detect patterns in images. Pooling reduces dimensions. Fully connected layer classifies. CNNs revolutionized computer vision. They are used in self-driving cars and medical diagnosis systems.

Answer 9. Transfer learning uses knowledge from one domain for another. Pre-trained models on ImageNet can be fine-tuned for medical images. This reduces need for large labeled datasets and training time significantly.

Answer 10. Cosine similarity compares vectors by calculating cosine of angle. Used in NLP to compare document similarity. Values range from 0 to 1. Higher values mean more similarity between documents or sentences.
"""
    },
    "STU003": {
        "name": "Ravi Kumar",
        "subject": "Machine Learning",
        "answers": """STUDENT ANSWER SHEET
Student ID: STU003 | Name: Ravi Kumar | Subject: Machine Learning

Answer 1. Machine learning is about making computers learn. It is AI technology. Systems get better automatically.

Answer 2. Neural networks have neurons. They are connected. They learn patterns.

Answer 3. Gradient descent finds minimum of function. It updates parameters. Learning rate is important.

Answer 4. NLP processes text. It includes many techniques for understanding language by computers.

Answer 5. Overfitting is bad model performance on test data. Regularization and dropout can help fix it.

Answer 6. TF-IDF measures word importance in text. Common words have low score. Rare important words have high score.

Answer 7. Supervised learning has labels. Unsupervised has no labels. Both are machine learning approaches for different scenarios.

Answer 8. CNN is for image processing. It has convolutional layers and pooling. Used in computer vision applications.

Answer 9. Transfer learning reuses trained models. It helps when data is less. Models like BERT are popular transfer learning models.

Answer 10. Cosine similarity measures document similarity. It uses vector representation. Values between 0 and 1.
"""
    }
}


def get_sample_questions():
    """Extract list of questions from sample paper."""
    import re
    matches = re.findall(r'Q\d+\.\s*(.+?)(?=\n\n|$)', SAMPLE_QUESTION_PAPER, re.DOTALL)
    return [m.strip() for m in matches]


def get_sample_key_answers():
    """Extract key answers."""
    import re
    matches = re.findall(r'A\d+\.\s*(.+?)(?=\n\nA\d+\.|$)', SAMPLE_KEY_ANSWERS, re.DOTALL)
    return [m.strip() for m in matches]


def get_sample_student_answers(student_key: str):
    """Extract student answers for a given student."""
    import re
    data = SAMPLE_STUDENT_ANSWERS.get(student_key, {})
    if not data:
        return [], "", ""
    text = data["answers"]
    matches = re.findall(r'Answer \d+\.\s*(.+?)(?=\n\nAnswer \d+\.|$)', text, re.DOTALL)
    answers = [m.strip() for m in matches]
    return answers, data["name"], data["subject"]
