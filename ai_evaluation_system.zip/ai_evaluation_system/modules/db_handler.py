"""
AI Answer Evaluation System - Database Module
==============================================
Handles MySQL operations with graceful fallback
to in-memory storage when MySQL is unavailable.
"""

import json
import datetime
from typing import List, Dict, Optional, Any

# ─────────────────────────────────────────────
# In-Memory Store (fallback when MySQL offline)
# ─────────────────────────────────────────────

_store = {
    "students": {},
    "evaluation_results": [],
    "student_final_results": [],
    "evaluation_sessions": [],
    "uploaded_files": [],
    "analytics_logs": [],
}

_session_counter = 1
_eval_counter = 1
_result_counter = 1


def _get_session_id():
    global _session_counter
    sid = _session_counter
    _session_counter += 1
    return sid


# ─────────────────────────────────────────────
# MySQL Connection (optional)
# ─────────────────────────────────────────────

_mysql_conn = None

def get_mysql_connection(host="localhost", user="root", password="", database="ai_evaluation_db"):
    """Try to connect to MySQL; returns None if unavailable."""
    global _mysql_conn
    try:
        import mysql.connector
        conn = mysql.connector.connect(
            host=host, user=user, password=password,
            database=database, connect_timeout=3
        )
        _mysql_conn = conn
        return conn
    except Exception:
        return None


def mysql_available() -> bool:
    return _mysql_conn is not None and _mysql_conn.is_connected()


# ─────────────────────────────────────────────
# Public API — works with or without MySQL
# ─────────────────────────────────────────────

def save_student(student_id: str, student_name: str, subject_name: str) -> bool:
    """Save student record."""
    record = {
        "student_id": student_id,
        "student_name": student_name,
        "subject_name": subject_name,
        "created_at": str(datetime.datetime.now()),
    }
    _store["students"][student_id] = record

    if mysql_available():
        try:
            cur = _mysql_conn.cursor()
            cur.execute(
                "INSERT IGNORE INTO students (student_id, student_name, subject_name) VALUES (%s, %s, %s)",
                (student_id, student_name, subject_name)
            )
            _mysql_conn.commit()
        except Exception:
            pass
    return True


def save_evaluation_results(session_id: int, student_id: str,
                             results: List[Dict], summary: Dict) -> bool:
    """Persist question-level evaluation results."""
    global _eval_counter, _result_counter

    for r in results:
        record = {
            "evaluation_id": _eval_counter,
            "session_id": session_id,
            "student_id": student_id,
            "question_number": r["question_number"],
            "question_text": r["question"],
            "key_answer": r["key_answer"],
            "student_answer": r["student_answer"],
            "similarity_score": r["similarity_score"],
            "confidence_score": r["confidence_score"],
            "obtained_marks": r["obtained_marks"],
            "total_marks": r["total_marks"],
            "ai_remarks": r["ai_remarks"],
            "keyword_match_count": len(r.get("matched_keywords", [])),
        }
        _store["evaluation_results"].append(record)
        _eval_counter += 1

    # Save student final result
    stu = _store["students"].get(student_id, {})
    final = {
        "result_id": _result_counter,
        "session_id": session_id,
        "student_id": student_id,
        "student_name": stu.get("student_name", student_id),
        "subject_name": stu.get("subject_name", "Unknown"),
        "total_obtained": summary.get("total_obtained", 0),
        "total_marks": summary.get("total_marks", 0),
        "percentage": summary.get("percentage", 0),
        "grade": summary.get("grade", "F"),
        "pass_fail": summary.get("pass_fail", "Fail"),
        "created_at": str(datetime.datetime.now()),
    }
    _store["student_final_results"].append(final)
    _result_counter += 1
    return True


def get_all_final_results(session_id: Optional[int] = None) -> List[Dict]:
    results = _store["student_final_results"]
    if session_id is not None:
        results = [r for r in results if r["session_id"] == session_id]
    return results


def get_question_results(student_id: str) -> List[Dict]:
    return [r for r in _store["evaluation_results"] if r["student_id"] == student_id]


def get_all_students() -> List[Dict]:
    return list(_store["students"].values())


def create_session(name: str = "Evaluation Session") -> int:
    sid = _get_session_id()
    _store["evaluation_sessions"].append({
        "session_id": sid,
        "session_name": name,
        "created_at": str(datetime.datetime.now()),
    })
    return sid


def log_action(action: str, details: str = ""):
    _store["analytics_logs"].append({
        "action": action,
        "details": details,
        "timestamp": str(datetime.datetime.now()),
    })


def get_dashboard_stats() -> Dict:
    """Compute live dashboard KPIs from in-memory store."""
    finals = _store["student_final_results"]
    total = len(finals)
    if total == 0:
        return {"total_students": 0, "total_evaluated": 0,
                "avg_score": 0, "pass_percentage": 0}
    avg_score = sum(f["percentage"] for f in finals) / total
    passes = sum(1 for f in finals if f["pass_fail"] == "Pass")
    return {
        "total_students": total,
        "total_evaluated": total,
        "avg_score": round(avg_score, 1),
        "pass_percentage": round(passes / total * 100, 1),
    }


def clear_all_data():
    """Reset in-memory store (for demo reset)."""
    global _session_counter, _eval_counter, _result_counter
    _store["students"].clear()
    _store["evaluation_results"].clear()
    _store["student_final_results"].clear()
    _store["evaluation_sessions"].clear()
    _store["uploaded_files"].clear()
    _store["analytics_logs"].clear()
    _session_counter = 1
    _eval_counter = 1
    _result_counter = 1
